Welcome to The Company E-Voucher Installation.

Requirements for the Software to run:
1.Microsoft Access or Software that reads .accdb files extention 
2.Microsoft Excel or Software that reads .xlsx files extention 
3. .Net Framework 4.7.2

Installation Guideline
1. Open setup.exe and install
2. Copy and Paste files inside Database folder to Local Disk D of your Computer
**Easier if The Company E-Vouhcer File is extracted. 

Troubleshooting
1.If unable to print/add to database, install the access plugins after downloading from following links:

Access Database Engine 2010
https://www.microsoft.com/en-us/download/details.aspx?id=13255

If still unable, install Access Database Engine 2007

Thank You for using The Company E-Voucher.
-Muhammad Sakib Khan
